from django.contrib import admin
from CreditCardFD.models import upload1
admin.site.register(upload1)
